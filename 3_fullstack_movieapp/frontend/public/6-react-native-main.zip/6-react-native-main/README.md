## Kütüphanaler

- react-native-linear-gradient
- https://www.figma.com/design/R1nWjKlB6mdpDrvDa0lPXi/Instagram-UI-Kit-(Community)?node-id=279-583&t=Z3WL3SUPp4KK7qOK-0
