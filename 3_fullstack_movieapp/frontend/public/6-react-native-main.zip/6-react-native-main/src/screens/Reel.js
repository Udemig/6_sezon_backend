import {View, Text} from 'react-native';
import React from 'react';

export default function Reel() {
  return (
    <View>
      <Text>Reel</Text>
    </View>
  );
}
