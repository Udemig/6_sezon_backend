import {View, Text} from 'react-native';
import React from 'react';

export default function Shop() {
  return (
    <View>
      <Text>Shop</Text>
    </View>
  );
}
