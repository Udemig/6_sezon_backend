export default [
  {
    id: 1,
    user: {
      name: 'Jane Doe',
      avatar: 'https://randomuser.me/api/portraits/women/1.jpg',
    },
  },
  {
    id: 2,
    user: {
      name: 'John Smith',
      avatar: 'https://randomuser.me/api/portraits/men/1.jpg',
    },
  },
  {
    id: 3,
    user: {
      name: 'Alice Johnson',
      avatar: 'https://randomuser.me/api/portraits/women/2.jpg',
    },
  },
  {
    id: 4,
    user: {
      name: 'Robert Brown',
      avatar: 'https://randomuser.me/api/portraits/men/2.jpg',
    },
  },
  {
    id: 5,
    user: {
      name: 'Emily Davis',
      avatar: 'https://randomuser.me/api/portraits/women/3.jpg',
    },
  },
  {
    id: 6,
    user: {
      name: 'Michael Wilson',
      avatar: 'https://randomuser.me/api/portraits/men/3.jpg',
    },
  },
  {
    id: 7,
    user: {
      name: 'Jessica Miller',
      avatar: 'https://randomuser.me/api/portraits/women/4.jpg',
    },
  },
  {
    id: 8,
    user: {
      name: 'David Martinez',
      avatar: 'https://randomuser.me/api/portraits/men/4.jpg',
    },
  },
  {
    id: 9,
    user: {
      name: 'Sarah Anderson',
      avatar: 'https://randomuser.me/api/portraits/women/5.jpg',
    },
  },
  {
    id: 10,
    user: {
      name: 'Daniel Thomas',
      avatar: 'https://randomuser.me/api/portraits/men/5.jpg',
    },
  },
];
