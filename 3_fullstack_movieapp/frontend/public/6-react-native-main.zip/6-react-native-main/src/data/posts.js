export default [
  {
    id: 1,
    description:
      'React Native ile mobil uygulama geliştirmek için harika bir rehber.React Native ile mobil uygulama geliştirmek için harika bir rehber.React Native ile mobil uygulama geliştirmek için harika bir rehber.React Native ile mobil uygulama geliştirmek için harika bir rehber.',
    date: '2024-06-02 11:00:00',
    likes: 150,
    comments: 30,
    image: 'https://picsum.photos/1080/607',
    user: {
      name: 'Ali',
      avatar: 'https://randomuser.me/api/portraits/men/1.jpg',
    },
  },
  {
    id: 2,
    description: 'Gün batımında harika bir manzara.',
    date: '2023-05-13',
    likes: 200,
    comments: 50,
    image: 'https://picsum.photos/1080/608',

    user: {
      name: 'Ali Veli',
      avatar: 'https://randomuser.me/api/portraits/men/2.jpg',
    },
  },
  {
    id: 3,
    description: 'Deniz kenarında yürüyüş.',
    date: '2023-05-14',
    likes: 120,
    comments: 20,
    image: 'https://picsum.photos/1080/609',

    user: {
      name: 'Ayşe Yılmaz',
      avatar: 'https://randomuser.me/api/portraits/women/3.jpg',
    },
  },
  {
    id: 4,
    description: 'Doğada huzur bulmak.',
    date: '2023-05-15',
    likes: 300,
    comments: 80,
    image: 'https://picsum.photos/1080/610',

    user: {
      name: 'Mehmet Kaya',
      avatar: 'https://randomuser.me/api/portraits/men/4.jpg',
    },
  },
  {
    id: 5,
    description: 'Kahve molası.',
    date: '2023-05-16',
    likes: 180,
    comments: 40,
    image: 'https://picsum.photos/1080/611',

    user: {
      name: 'Fatma Demir',
      avatar: 'https://randomuser.me/api/portraits/women/5.jpg',
    },
  },
  {
    id: 6,
    description: 'Şehirde bir akşam.',
    date: '2023-05-17',
    likes: 250,
    comments: 70,
    image: 'https://picsum.photos/1080/612',

    user: {
      name: 'Canan Ak',
      avatar: 'https://randomuser.me/api/portraits/women/6.jpg',
    },
  },
  {
    id: 7,
    description: 'Sahil kenarında kamp.',
    date: '2023-05-18',
    likes: 220,
    comments: 60,
    image: 'https://picsum.photos/1080/607',

    user: {
      name: 'Burak Taş',
      avatar: 'https://randomuser.me/api/portraits/men/7.jpg',
    },
  },
  {
    id: 8,
    description: 'Gökyüzüne bakmak.',
    date: '2023-05-19',
    likes: 310,
    comments: 90,
    image: 'https://picsum.photos/1080/613',

    user: {
      name: 'Elif Sönmez',
      avatar: 'https://randomuser.me/api/portraits/women/8.jpg',
    },
  },
  {
    id: 9,
    description: 'Doğanın içinde kaybolmak.',
    date: '2023-05-20',
    likes: 270,
    comments: 85,
    image: 'https://picsum.photos/1080/614',
    user: {
      name: 'Ahmet Yıldız',
      avatar: 'https://randomuser.me/api/portraits/men/9.jpg',
    },
  },
  {
    id: 10,
    description: 'Kitap okuma saati.',
    date: '2023-05-21',
    likes: 160,
    comments: 45,
    image: 'https://picsum.photos/1080/615',
    user: {
      name: 'Zeynep Kılıç',
      avatar: 'https://randomuser.me/api/portraits/women/10.jpg',
    },
  },
  {
    id: 11,
    description: 'Yemyeşil bir orman.',
    date: '2023-05-22',
    likes: 280,
    comments: 75,
    image: 'https://picsum.photos/1080/616',
    user: {
      name: 'Hasan Demir',
      avatar: 'https://randomuser.me/api/portraits/men/11.jpg',
    },
  },
  {
    id: 12,
    description: 'Dağlarda yürüyüş.',
    date: '2023-05-23',
    likes: 230,
    comments: 65,
    image: 'https://picsum.photos/1080/617',
    user: {
      name: 'Merve Kır',
      avatar: 'https://randomuser.me/api/portraits/women/12.jpg',
    },
  },
  {
    id: 13,
    description: 'Müzik dinleme keyfi.',
    date: '2023-05-24',
    likes: 190,
    comments: 55,
    image: 'https://picsum.photos/1080/618',
    user: {
      name: 'Kerem Çelik',
      avatar: 'https://randomuser.me/api/portraits/men/13.jpg',
    },
  },
  {
    id: 14,
    description: 'Sıcak bir kahve.',
    date: '2023-05-25',
    likes: 240,
    comments: 70,
    image: 'https://picsum.photos/1080/619',
    user: {
      name: 'Leyla Kılıç',
      avatar: 'https://randomuser.me/api/portraits/women/14.jpg',
    },
  },
  {
    id: 15,
    description: 'Kedimle oyun zamanı.',
    date: '2023-05-26',
    likes: 260,
    comments: 80,
    image: 'https://picsum.photos/1080/620',
    user: {
      name: 'Tuna Erbilen',
      avatar: 'https://randomuser.me/api/portraits/men/15.jpg',
    },
  },
  {
    id: 16,
    description: 'Denizde yüzmek.',
    date: '2023-05-27',
    likes: 300,
    comments: 90,
    image: 'https://picsum.photos/1080/621',
    user: {
      name: 'Sibel Çelik',
      avatar: 'https://randomuser.me/api/portraits/women/16.jpg',
    },
  },
  {
    id: 17,
    description: 'Bisiklet turu.',
    date: '2023-05-28',
    likes: 310,
    comments: 85,
    image: 'https://picsum.photos/1080/621',
    user: {
      name: 'Görkem Taş',
      avatar: 'https://randomuser.me/api/portraits/men/17.jpg',
    },
  },
  {
    id: 18,
    description: 'Yoga seansı.',
    date: '2023-05-29',
    likes: 320,
    comments: 95,
    image: 'https://picsum.photos/1080/622',
    user: {
      name: 'Deniz Ak',
      avatar: 'https://randomuser.me/api/portraits/women/18.jpg',
    },
  },
  {
    id: 19,
    description: 'Şehirde akşam yürüyüşü.',
    date: '2023-05-30',
    likes: 330,
    comments: 100,
    image: 'https://picsum.photos/1080/623',
    user: {
      name: 'Barış Yılmaz',
      avatar: 'https://randomuser.me/api/portraits/men/19.jpg',
    },
  },
  {
    id: 20,
    description: 'Sabah kahvaltısı.',
    date: '2023-05-31',
    likes: 340,
    comments: 110,
    image: 'https://picsum.photos/1080/624',
    user: {
      name: 'Esra Sönmez',
      avatar: 'https://randomuser.me/api/portraits/women/20.jpg',
    },
  },
];
